"""Adapter for Module 4 — GRU Sequence Classification over MRI Slices.

This adapter implements the agreed contract for Module 4:
1. Operates on ordered slices from ONE MRI volume (not longitudinal patient visits).
2. Extracts or receives per-slice features (e.g. from ResNet-18 backbone).
3. Evaluates a GRU sequence classifier for 3-class ACL diagnosis (Healthy, Partial tear, Complete rupture).
4. Returns 'status': 'unavailable' when the required GRU checkpoint is missing.
5. Keeps illustrative recovery trajectories strictly separate, labeled persistent SIMULATED.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn

from acl_mri_classification.model import CLASS_NAMES, build_model
from module2_preprocessing.preprocessing import normalize_resize_roi

logger = logging.getLogger("adapters.module4")


class GRUSliceSequenceClassifier(nn.Module):
    """Model owner's GRU architecture for sequence classification across MRI slices."""

    def __init__(self, input_size: int = 512, hidden_size: int = 64, num_classes: int = 3, num_layers: int = 1):
        super().__init__()
        self.gru = nn.GRU(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
        )
        self.classifier = nn.Linear(hidden_size, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [batch, num_slices, input_size]
        output, _ = self.gru(x)
        last_step = output[:, -1, :]
        return self.classifier(last_step)


class Module4Adapter:
    """Integration adapter for Module 4 GRU slice sequence classification."""

    def __init__(
        self,
        artifacts_dir: Path | str | None = None,
        resnet_checkpoint_path: Path | str | None = None,
        device: torch.device | None = None,
    ) -> None:
        root = Path(__file__).resolve().parents[1]
        self.artifacts_dir = Path(artifacts_dir) if artifacts_dir else root / "module4_recovery" / "artifacts"
        self.gru_checkpoint_path = self.artifacts_dir / "gru_checkpoint.pt"
        if resnet_checkpoint_path:
            self.resnet_checkpoint_path = Path(resnet_checkpoint_path)
        else:
            self.resnet_checkpoint_path = root / "acl_mri_classification" / "artifacts" / "deploy" / "resnet18.pt"

        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self._gru_model: nn.Module | None = None
        self._feature_extractor: nn.Module | None = None
        self._loaded = False

    def load_artifacts(self) -> bool:
        """Attempt to load trained GRU sequence model checkpoint if present."""
        if self._loaded:
            return self._gru_model is not None

        if self.gru_checkpoint_path.is_file():
            try:
                checkpoint = torch.load(self.gru_checkpoint_path, map_location=self.device, weights_only=False)
                cfg = checkpoint.get("config", {})
                input_size = int(cfg.get("input_size", 512))
                hidden_size = int(cfg.get("hidden_size", 64))
                num_classes = int(cfg.get("num_classes", 3))

                model = GRUSliceSequenceClassifier(input_size=input_size, hidden_size=hidden_size, num_classes=num_classes)
                model.load_state_dict(checkpoint["model_state_dict"])
                model.to(self.device).eval()
                self._gru_model = model
                self._loaded = True
                return True
            except Exception as exc:
                logger.warning("Failed loading GRU checkpoint from %s: %s", self.gru_checkpoint_path, exc)
                self._gru_model = None
                return False
        return False

    def _get_feature_extractor(self, existing_resnet_model: nn.Module | None = None) -> nn.Module | None:
        """Obtain slice feature extractor from ResNet-18."""
        if self._feature_extractor is not None:
            return self._feature_extractor

        if existing_resnet_model is not None:
            self._feature_extractor = existing_resnet_model
            return self._feature_extractor

        if self.resnet_checkpoint_path.is_file():
            try:
                cp = torch.load(self.resnet_checkpoint_path, map_location=self.device, weights_only=False)
                m = build_model("resnet18", pretrained=False).to(self.device)
                m.load_state_dict(cp["model_state_dict"])
                m.eval()
                self._feature_extractor = m
                return self._feature_extractor
            except Exception as exc:
                logger.warning("Could not build ResNet-18 feature extractor: %s", exc)
        return None

    def predict(
        self,
        volume: np.ndarray | None,
        row: dict[str, Any] | None,
        image_size: int = 160,
        existing_resnet_model: nn.Module | None = None,
        precomputed_slice_features: torch.Tensor | np.ndarray | None = None,
    ) -> dict[str, Any]:
        """Run GRU sequence classification over ordered slices of a single MRI volume.
        
        Returns a structured dictionary conforming to the agreed Module 4 contract.
        If required model weights are missing, returns status 'unavailable'.
        """
        has_gru = self.load_artifacts()
        if not has_gru:
            total_slices = volume.shape[0] if volume is not None else 0
            return {
                "status": "unavailable",
                "model_identity": "Module 4 GRU Slice Sequence Classifier",
                "architecture": "ResNet-18 Slice Embeddings + GRU(hidden=64, layers=1)",
                "reason": "GRU sequence classifier weights (gru_checkpoint.pt) not found in module4_recovery/artifacts/.",
                "input_scope": "Ordered sagittal slices from a single MRI volume",
                "is_longitudinal_recovery": False,
                "slices_available": total_slices,
            }

        if volume is None and precomputed_slice_features is None:
            return {
                "status": "unavailable",
                "model_identity": "Module 4 GRU Slice Sequence Classifier",
                "reason": "No volume or precomputed slice features provided for sequence evaluation.",
                "is_longitudinal_recovery": False,
            }

        try:
            # 1. Obtain slice embeddings sequence: [1, num_slices, 512]
            if precomputed_slice_features is not None:
                if isinstance(precomputed_slice_features, np.ndarray):
                    feats_seq = torch.from_numpy(precomputed_slice_features).float().to(self.device)
                else:
                    feats_seq = precomputed_slice_features.to(self.device)
                if feats_seq.ndim == 2:
                    feats_seq = feats_seq.unsqueeze(0)
            else:
                assert volume is not None
                feature_extractor = self._get_feature_extractor(existing_resnet_model)
                if feature_extractor is None:
                    return {
                        "status": "unavailable",
                        "model_identity": "Module 4 GRU Slice Sequence Classifier",
                        "reason": "ResNet-18 feature extractor unavailable for slice embeddings.",
                        "is_longitudinal_recovery": False,
                    }

                # Normalize and prepare slices
                norm_slices = normalize_resize_roi(volume, row or {}, image_size=image_size)
                num_slices = len(norm_slices)
                batch = torch.from_numpy(norm_slices.copy()).float().unsqueeze(1).to(self.device) / 255.0

                # Extract 512-d representations before classification layer
                backbone = getattr(feature_extractor, "backbone", feature_extractor)
                with torch.no_grad():
                    rgb = batch.repeat(1, 3, 1, 1)
                    # Use standard ImageNet normalization buffers if present
                    mean = getattr(feature_extractor, "mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1).to(self.device))
                    std = getattr(feature_extractor, "std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1).to(self.device))
                    rgb = (rgb - mean) / std

                    # Hook or extract pre-fc features from ResNet-18
                    x = backbone.conv1(rgb)
                    x = backbone.bn1(x)
                    x = backbone.relu(x)
                    x = backbone.maxpool(x)
                    x = backbone.layer1(x)
                    x = backbone.layer2(x)
                    x = backbone.layer3(x)
                    x = backbone.layer4(x)
                    x = backbone.avgpool(x)
                    slice_embeddings = torch.flatten(x, 1)  # [num_slices, 512]
                    feats_seq = slice_embeddings.unsqueeze(0)  # [1, num_slices, 512]

            # 2. Run GRU classification
            with torch.no_grad():
                logits = self._gru_model(feats_seq)
                probs = torch.softmax(logits, dim=1)[0].cpu().tolist()
                pred_label = int(np.argmax(probs))

            return {
                "status": "available",
                "model_identity": "Module 4 GRU Slice Sequence Classifier",
                "architecture": "ResNet-18 Slice Embeddings + GRU(hidden=64, layers=1)",
                "predicted_label": pred_label,
                "predicted_class": CLASS_NAMES[pred_label],
                "confidence": float(round(probs[pred_label], 4)),
                "probabilities": {cls: float(round(p, 4)) for cls, p in zip(CLASS_NAMES, probs)},
                "slices_evaluated": feats_seq.shape[1],
                "input_scope": "Ordered sagittal slices from a single MRI volume",
                "is_longitudinal_recovery": False,
            }
        except Exception as exc:
            logger.error("GRU sequence classification failed: %s", exc)
            return {
                "status": "unavailable",
                "model_identity": "Module 4 GRU Slice Sequence Classifier",
                "reason": f"Inference execution failed: {exc}",
                "is_longitudinal_recovery": False,
            }

    @staticmethod
    def get_simulated_recovery_trajectory(
        acl_severity: int = 0,
        treatment: str = "rehab",
    ) -> dict[str, Any]:
        """Return illustrative recovery trajectory data strictly separated from GRU classification.
        
        Explicitly marked persistent SIMULATED. Not a trained model prediction or clinical claim.
        """
        # Illustrative timeline curves based on severity and treatment
        severity_adj = {0: 10.0, 1: 0.0, 2: -15.0}.get(acl_severity, 0.0)
        treatment_adj = 4.0 if treatment == "surgery" and acl_severity > 0 else 0.0

        m0 = round(max(20.0, min(95.0, 60.0 + severity_adj)), 1)
        m3 = round(min(100.0, m0 + 15.0 + treatment_adj * 0.5), 1)
        m6 = round(min(100.0, m3 + 8.0 + treatment_adj * 0.3), 1)
        m12 = round(min(100.0, m6 + 5.0 + treatment_adj * 0.2), 1)

        degradation_risk = "low" if acl_severity == 0 else "moderate" if acl_severity == 1 else "elevated"

        return {
            "status": "simulated",
            "record_type": "SIMULATED",
            "label": "SIMULATED",
            "time_points_months": [0, 3, 6, 12],
            "trajectory": [
                {"month": 0, "score": m0},
                {"month": 3, "score": m3},
                {"month": 6, "score": m6},
                {"month": 12, "score": m12},
            ],
            "projected_12m_score": m12,
            "score_system": "IKDC / KOOS Functional Outcome Points (0-100 scale)",
            "degradation_risk": degradation_risk,
            "treatment_context": treatment,
            "disclaimer": "SIMULATED TEACHING DATA ONLY. Illustrative trajectory, NOT a trained model prediction or clinical prognosis.",
            "is_trained_prediction": False,
        }
